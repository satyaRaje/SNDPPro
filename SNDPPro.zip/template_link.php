<html>
<body>
<a href="#" class="w3-bar-item w3-button">Overview</a>
<a href="#" class="w3-bar-item w3-button">Careers</a>
<a href="#" class="w3-bar-item w3-button">History</a>
<a href="#" class="w3-bar-item w3-button">Our Approach</a>
<a href="#" class="w3-bar-item w3-button">Our Team</a>
<a href="#" class="w3-bar-item w3-button">Authenticate</a>
<a href="#" class="w3-bar-item w3-button">Accuracy</a>


</body>


</html>