<html>
<body>
<a href="services.php" class="w3-bar-item w3-button">Services</a>
<a href="3dprinting.php" class="w3-bar-item w3-button">3D Printing</a>
<a href="3dscanning.php" class="w3-bar-item w3-button">3D Scanning</a>
<a href="rapidprototyping.php" class="w3-bar-item w3-button">Rapid Prototyping</a>
<a href="cadmodeling.php" class="w3-bar-item w3-button">3D & 2D CAD Modeling</a>
<a href="design.php" class="w3-bar-item w3-button">Design for 3D Printing</a>
<a href="reverse.php" class="w3-bar-item w3-button">Reverse Engineering</a>
<a href="topology.php" class="w3-bar-item w3-button">Design Topology Optimization</a>
<a href="manufacturing.php" class="w3-bar-item w3-button">Small Batch Production</a>
<a href="vaccumecast.php" class="w3-bar-item w3-button">Vaccum Casting</a>
<a href="xraytopology.php" class="w3-bar-item w3-button">X-Ray Topography</a>
<a href="functional.php" class="w3-bar-item w3-button">Functional part Manufacturing</a>
<a href="toolmanufacture.php" class="w3-bar-item w3-button">Tooling Manufacturing</a>
<a href="injectionmedelling.php" class="w3-bar-item w3-button">Injection Modelling</a>
<a href="cncmachine.php" class="w3-bar-item w3-button">CNC Machining</a>
</body>
</html>