<html>
<body>
<a href="aboutus.php" class="w3-bar-item w3-button">About Us</a>
<a href="overview.php" class="w3-bar-item w3-button">Overview</a>
<a href="history.php" class="w3-bar-item w3-button">History</a>
<a href="ourapproach.php" class="w3-bar-item w3-button">Our Approach</a>
<a href="ourteam.php" class="w3-bar-item w3-button">Our Team</a>
<a href="companyethics.php" class="w3-bar-item w3-button">Company Ethics</a>
<a href="authentic.php" class="w3-bar-item w3-button">Authentic</a>
<a href="accuracy.php" class="w3-bar-item w3-button">Accuracy</a>
<a href="careers.php" class="w3-bar-item w3-button">Careers</a>



</body>


</html>