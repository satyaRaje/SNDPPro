<div class="container-fluid">

    <div class="row text-center w3-black">

        <div class="col-sm-3">
            <h3>Our Services</h3>
            <h5>3D Printing</h5>
            <h5>3D Scanning</h5>
            <h5>2D & 3D design services</h5>
            <h5>Design for 3D Printing</h5>
            <h5>Many more services…..</h5>

        </div>

        <div class="col-sm-3">
            <br><br>
            <h5><b>IPRO3D TECHNOLOGIES LLP</b><br>
                Incubation Office<br>
                <b>IPRO3D TECHNOLOGIES LLP,</b><br>
                C/O Er. Yogesh Pawar,<br>
                Workstation-1, MAGIC, CMIA office,<br>
                Bajaj Bhavan, Near MIDC office,<br>
                Railway Station Road, Aurangabad,<br>
                Maharashtra, India.<h5>

        </div>
        <div class="col-sm-3">
            <br><br>
            <h5>
                <b>Corporate office Manufacturing Facility</b><br>
                Address:<br>
                <b>IPRO3D TECHNOLOGIES LLP,</b><br>
                C/O Er. Yogesh Pawar,<br>
                Meridian Status-B, F-7,<br>
                Near Youth Hostel, Kesarsingpura,<br>
                Aurangabad-431005, Maharashtra,<br>
                India.<br>

            </h5>
        </div>


        <div class="col-sm-3">
            <br><br><br>
            <div class="w3-xxlarge">
                <i class="fa fa-facebook-official w3-hover-opacity"></i>
                <i class="fa fa-instagram w3-hover-opacity"></i>
                <i class="fa fa-snapchat w3-hover-opacity"></i>
                <i class="fa fa-pinterest-p w3-hover-opacity"></i>
                <i class="fa fa-twitter w3-hover-opacity"></i>
                <i class="fa fa-linkedin w3-hover-opacity"></i>
                <a href="https://api.whatsapp.com/send?phone=919821413663" class="float" target="_blank">
                    <i class="fa fa-whatsapp my-float"></i></a>
            </div>
            <h4 style="background-color: gray">Mobile : +91 9821413663</h4>
            <h4>Email : hello@ipro3d.io</h4>
        </div>
    </div>
</div>
